﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funciones
{
    class Operaciones
    {

        public int restar(int a, int b)
        {
            return a - b;
        }

        public int sumar(int a, int b)
        {
            return a + b;
        }

        public double dividir(int a, int b)
        {
            return a / b;
        }

        public int multiplicar(int a, int b)
        {
            return a * b;
        }

    }

    class Constantes
    {
        double

    }

}
