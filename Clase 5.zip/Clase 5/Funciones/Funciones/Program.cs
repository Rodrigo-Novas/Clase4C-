﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funciones
{
    class Program
    {
        //Random rand = new Random();

        //static int GenerarRand(int valorMinimo, int valorMaximo)
        //{

            
        //    int random = rand.Next(valorMinimo, valorMaximo);

          
        //    return random;
        //}

        static void Main(string[] args)
        {
            //int random=0;

            //random = GenerarRand(10, 100);

            Operaciones operaciones = new Operaciones();
            int sumas;
            sumas = operaciones.sumar(8, 10);

            Console.WriteLine("La suma es {0}", sumas);
            
            Console.Read();
        }
    }
}
