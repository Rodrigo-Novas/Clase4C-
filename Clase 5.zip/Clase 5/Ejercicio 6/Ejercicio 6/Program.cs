﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Copiar el contenido del arreglo origen al arreglo destino, dejando en este último los valores invertidos respecto del arreglo origen.Utilizar
//estructura de control de flujo repetitiva, y luego informar el índice y los valores del nuevo arreglo.
//Por ejemplo, informar de la siguiente manera:
//Arreglo origen
//0 1002
//1 104
//2 309
//3 500
//Arreglo destino
//0 500
//1 309
//2 104
//3 1002

namespace Ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] ArrayOrigen = {100, 104,309,500};
            int[] ArrayDestino = new int[ArrayOrigen.Length];
            //Random rand= new random();

            /*for(int i=0; i<origen.lenght;i++
             * {
             * origen[i]=rand.next(1,100);
             * }
             * carga numeros aleatorios*/


            //espejar array
            for (int i=0, j=ArrayDestino.Length-1; i<ArrayOrigen.Length; i++, j--) //el primero lo que hace es iterar el primer array y el j va bajando para tomar el primero de origen como ultimo de destino
            {
                ArrayDestino[j] = ArrayOrigen[i];

            }

            //lo muestro por pantalla aca porque si lo muestro en el otro for va a iterar cualquier cosa
            for (int i = 0; i < ArrayDestino.Length; i++)
            {
                Console.WriteLine("{0}", ArrayDestino[i]);
            }

            Console.Read();
        }
    }
}
