﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;





namespace Clase
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Dado el arreglo { 10,20,5,15,30,20}
            Informar el arreglo de la forma: "Indice: X, Valor: Y"
               Totalizar el arreglo e informar el total
                Informar el contenido de las posiciones impares(por ejemplo, las posiciones 1,3,5,etc)
                Informar el mayor número*/


            int[] numeros = { 10, 20, 5, 15, 30, 20 };
            int suma=0;
            int mayor = numeros[0];
            int menor = numeros[0];
            int contadorVeinte = 0;
            //saco menores y suma
            for (int i=0; i<6; i++)
            {
                Console.WriteLine("El indice es: {0} - El valor es: {1}", i, numeros[i]);

                suma = numeros[i]+suma;

                

                if(numeros[i]<menor )
                {
                    menor = numeros[i];
                }

                if (numeros[i] > mayor)
                {
                   mayor = numeros[i];
                }

                if (numeros[i]==20)
                {
                    contadorVeinte++;
                }
            }

            //saco impares
            Console.WriteLine("Los impares son");
            for (int i = 0; i < 6; i++)
            {

                if(numeros[i]%2!=0)
                {
                    
                    Console.WriteLine("El indice es: {0} - El valor es: {1}", i, numeros[i]);
                }

            }

            Console.WriteLine("La suma total es: {0}", suma);
            Console.WriteLine("La cantidad de 20 es: {0}", contadorVeinte);
            Console.WriteLine("El menor es: {0}", menor);
            Console.WriteLine("El mayor es: {0}", mayor);
            Console.Read();

        }
    }
}
